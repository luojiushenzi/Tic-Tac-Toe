package com.example.tictactoe;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {
    // Represents the internal state of the game
    private TicTacToeGame mGame;

    // Buttons making up the board
    private Button mBoardButtons[];
    // Various text displayed
    private TextView mInfoTextView;
    // Restart Button
    private Button startButton;
    private TextView mKeepTrack;
    // Game Over
    Boolean mGameOver;
    private int nUser = 0;
    private int nAndroid = 0;
    private int ntie = 0;
    private int model = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mGame = new TicTacToeGame();
        mBoardButtons = new Button[mGame.BOARD_SIZE];
        mBoardButtons[0] = (Button) findViewById(R.id.button0);
        mBoardButtons[1] = (Button) findViewById(R.id.button1);
        mBoardButtons[2] = (Button) findViewById(R.id.button2);
        mBoardButtons[3] = (Button) findViewById(R.id.button3);
        mBoardButtons[4] = (Button) findViewById(R.id.button4);
        mBoardButtons[5] = (Button) findViewById(R.id.button5);
        mBoardButtons[6] = (Button) findViewById(R.id.button6);
        mBoardButtons[7] = (Button) findViewById(R.id.button7);
        mBoardButtons[8] = (Button) findViewById(R.id.button8);
        mInfoTextView = (TextView) findViewById(R.id.information);
        mKeepTrack = (TextView) findViewById(R.id.keep_track);
        mGame = new TicTacToeGame();
        startNewGame();
    }

    //--- Set up the game board.
    private void startNewGame() {
        mInfoTextView.animate().scaleX(1f).scaleY(1f).setDuration(0);
        MediaPlayer mediaPlayer;
        Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.start);
        mediaPlayer= MediaPlayer.create(getApplicationContext(),uri);
        mediaPlayer.start();
        mGameOver = false;
        mGame.clearBoard();
        //---Reset all buttons
        for (int i = 0; i < mBoardButtons.length; i++) {
            mBoardButtons[i].setText("");
            mBoardButtons[i].setEnabled(true);
            mBoardButtons[i].setOnClickListener(new ButtonClickListener(i));
        }
        //---Human goes first
        if(TicTacToeGame.mUser_first==true){
            mInfoTextView.setText(R.string.user_go);
        }
        else{
            mInfoTextView.setText(R.string.android_go);
            if(model==1){
                int move = mGame.getComputerMove_easy();
                setMove(TicTacToeGame.COMPUTER_PLAYER, move);
            }
            else if(model==2){
                int move = mGame.getComputerMove_harder();
                setMove(TicTacToeGame.COMPUTER_PLAYER, move);
            }
            else if(model==3){
                int move = mGame.getComputerMove_expert();
                setMove(TicTacToeGame.COMPUTER_PLAYER, move);
            }
            //setMove(TicTacToeGame.COMPUTER_PLAYER, move);
        }
        //mKeepTrack.setText("User won "+String.valueOf(nUser)+" times, Android won "+
        //        String.valueOf(nAndroid)+" times, and drew "+String.valueOf(ntie)+" times.");
        mKeepTrack.setText(getString(R.string.user_won)+String.valueOf(nUser)+getString(R.string.android_won)+
                String.valueOf(nAndroid)+getString(R.string.ties)+String.valueOf(ntie)+getString(R.string.times));
    }

    //---Handles clicks on the game board buttons
    private class ButtonClickListener implements View.OnClickListener {
        int location;
        private  MediaPlayer mediaPlayer;
        public ButtonClickListener(int location) {
            this.location = location;
        }
        @Override
        public void onClick(View v) {
            if (mGameOver == false) {
                if (mBoardButtons[location].isEnabled()) {
                    setMove(TicTacToeGame.HUMAN_PLAYER, location);
                    //--- If no winner yet, let the computer make a move
                    int winner = mGame.checkForWinner();
                    if (winner == 0) {
                        mInfoTextView.setText(R.string.android_turn);
                        if(model==1){
                            int move = mGame.getComputerMove_easy();
                            setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                        }
                        else if(model==2){
                            int move = mGame.getComputerMove_harder();
                            setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                        }
                        else if(model==3){
                            int move = mGame.getComputerMove_expert();
                            setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                        }
                        //int move = mGame.getComputerMove();
                        //setMove(TicTacToeGame.COMPUTER_PLAYER, move);
                        winner = mGame.checkForWinner();
                    }
                    if (winner == 0) {
                        mInfoTextView.setTextColor(Color.rgb(0, 0, 0));
                        mInfoTextView.setText(R.string.user_turn);
                    } else if (winner == 1) {
                        mInfoTextView.setTextColor(Color.rgb(0, 0, 200));
                        mInfoTextView.setText(R.string.tie);
                        mInfoTextView.animate().scaleX(2f).scaleY(2f).setDuration(4000);
                        mGameOver = true;
                        TicTacToeGame.mUser_first=!TicTacToeGame.mUser_first;
                        ntie++;
                    } else if (winner == 2) {
                        mInfoTextView.setTextColor(Color.rgb(0, 200, 0));
                        mInfoTextView.setText(R.string.user_win);
                        mInfoTextView.animate().scaleX(2f).scaleY(2f).setDuration(4000);
                        Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.victory);
                        mediaPlayer= MediaPlayer.create(getApplicationContext(),uri);
                        mediaPlayer.start();
                        mGameOver = true;
                        TicTacToeGame.mUser_first=!TicTacToeGame.mUser_first;
                        nUser++;
                    } else {
                        mInfoTextView.setTextColor(Color.rgb(200, 0, 0));
                        mInfoTextView.setText(R.string.android_win);
                        mInfoTextView.animate().scaleX(2f).scaleY(2f).setDuration(4000);
                        Uri uri = Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.defeat);
                        mediaPlayer= MediaPlayer.create(getApplicationContext(),uri);
                        mediaPlayer.start();
                        mGameOver = true;
                        TicTacToeGame.mUser_first=!TicTacToeGame.mUser_first;
                        nAndroid++;
                    }
                }
            }
        }
    }

    private void setMove(char player, int location) {
        mGame.setMove(player, location);
        mBoardButtons[location].setEnabled(false);
        mBoardButtons[location].setText(String.valueOf(player));
        //mBoardButtons[location].animate().setDuration(3000).setInterpolator(new AccelerateInterpolator()).rotationBy(180.0f);
        if (player == TicTacToeGame.HUMAN_PLAYER)
            mBoardButtons[location].setTextColor(Color.rgb(0, 200, 0));
        else
            mBoardButtons[location].setTextColor(Color.rgb(200, 0, 0));
    }

    //--- OnClickListener for Restart a New Game Button
    public void newGame(View v) {
        startNewGame();
    }

    // --- Option Menu ---
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_options, menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.menu_wiki:
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://baike.baidu.com/item/%E4%BA%95%E5%AD%97%E6%A3%8B/4467444?fr=aladdin"));
                startActivity(intent);
                return true;
            case R.id.menu_exit:
                finish();
                return true;
            case R.id.menu_easy:
                model=1;
                startNewGame();
                return true;
            case R.id.menu_harder:
                model=2;
                startNewGame();
                return true;
            case R.id.menu_expert:
                model=3;
                startNewGame();
                return true;
        }
        return false;
    }
}


